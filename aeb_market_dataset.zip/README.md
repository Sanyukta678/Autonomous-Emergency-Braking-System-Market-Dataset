# Autonomous Emergency Braking (AEB) System Market – Dataset

This repository contains structured market data for the Autonomous Emergency Braking System (AEB) Market (Report Code: AT3571).  
Dataset style inspired by the Immunoglobulin Market Dataset.

## **Included Files**
- `market_overview.csv` — Market size & CAGR data  
- `segmentation.csv` — Segmentation by system type, technology, vehicle type, end-user, and region  
- `metadata.json` — Source details and dataset metadata  
- `README.md` — Overview and licensing

## **Source**
Data derived from:  
https://www.nextmsc.com/report/autonomous-emergency-braking-system-market-at3571

## **Usage**
You may use this dataset for academic, research, or analytical purposes.

## **License**
Open-use for non‑commercial analytical work.
